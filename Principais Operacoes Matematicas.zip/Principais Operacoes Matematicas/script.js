let Numero1 = document.querySelector("#Numero1");
let Numero2 = document.querySelector("#Numero2");
let btCalcular = document.querySelector("#btCalcular");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let num1 = Number(Numero1.value);
  let num2 = Number(Numero2.value);

  let soma = (num1 + num2);

  let subtracao = (num1 - num2);

  let multiplicacao = (num1 * num2);

  let divisao = (num1 / num2);

  Resultado.innerHTML = "Soma" + soma + "<br>" + 
  "Subtração:" + subtracao + "<br>" + 
  "Multiplicação:" + multiplicacao + "<br>" + 
  "Divisão:" + divisao;
}

btCalcular.onclick = function() {
    Calcular();
}